import type { TrafficSignal, SignalState, SignalRuntime } from '@/types/signal';
import { useSignalCycler } from '@/hooks/useSignalCycler';
import { stateByElapsed } from '@/lib/signal-utils';

interface AdminPanelProps {
  signals: TrafficSignal[];
  onUpdate: (id: string, state: SignalState) => void;
  speed: number;
  onSpeedChange: (speed: number) => void;
  getRuntime: (id: string) => SignalRuntime | undefined;
}

const STATE_DOT: Record<string, string> = {
  RED: 'bg-signal-red',
  GREEN: 'bg-signal-green',
  YELLOW: 'bg-signal-yellow',
};

export default function AdminPanel({
  signals,
  onUpdate,
  speed,
  onSpeedChange,
  getRuntime,
}: AdminPanelProps) {
  const { cycling, startCycling, stopCycling } = useSignalCycler();

  return (
    <div className="bg-card rounded-lg border border-border p-4">
      <div className="flex items-center justify-between mb-3">
        <h2 className="text-sm font-mono font-bold text-foreground tracking-wider uppercase">
          Signal Control
        </h2>
        <button
          onClick={cycling ? stopCycling : startCycling}
          className={`px-3 py-1 rounded text-xs font-mono font-semibold transition-all ${
            cycling
              ? 'bg-destructive text-destructive-foreground'
              : 'bg-primary text-primary-foreground'
          }`}
        >
          {cycling ? '⏹ Stop' : '▶ Cycle'}
        </button>
      </div>

      {/* Speed setting */}
      <div className="flex items-center gap-2 mb-3 bg-secondary/50 rounded-md px-3 py-2">
        <span className="text-[10px] font-mono text-muted-foreground">Speed:</span>
        <input
          type="number"
          min={5}
          max={120}
          value={speed}
          onChange={(e) => onSpeedChange(Math.max(5, Number(e.target.value) || 35))}
          className="w-14 px-1.5 py-0.5 rounded text-xs font-mono bg-muted text-foreground border border-border text-center"
        />
        <span className="text-[10px] font-mono text-muted-foreground">km/h</span>
      </div>

      {/* Signals */}
      <div className="space-y-2">
        {signals.map((signal) => {
          const runtime = getRuntime(signal.id);
          const currentState = runtime
            ? stateByElapsed(runtime.elapsed, runtime.cycle).state
            : signal.state;
          const remaining = runtime
            ? stateByElapsed(runtime.elapsed, runtime.cycle).remaining
            : 0;

          return (
            <div
              key={signal.id}
              className="bg-secondary/50 rounded-md px-3 py-2"
            >
              <div className="flex items-center gap-2 mb-1">
                <div
                  className={`w-3 h-3 rounded-full ${STATE_DOT[currentState]} animate-pulse-signal`}
                />
                <span className="font-mono text-xs font-semibold text-foreground">
                  {signal.id}
                </span>
                <span className="text-[10px] font-mono text-muted-foreground flex-1 truncate">
                  {signal.roadName}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-[10px] font-mono text-muted-foreground">
                  {currentState} · {Math.round(remaining)}s left
                </span>
                <div className="flex gap-1">
                  {(['RED', 'GREEN'] as SignalState[]).map((state) => (
                    <button
                      key={state}
                      onClick={() => onUpdate(signal.id, state)}
                      disabled={currentState === state}
                      className={`px-2 py-0.5 rounded text-[10px] font-mono font-bold transition-all ${
                        currentState === state
                          ? `${STATE_DOT[state]} text-background`
                          : 'bg-muted text-muted-foreground hover:bg-secondary'
                      }`}
                    >
                      {state}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
