import { useState, useEffect, useCallback, useRef } from 'react';
import { supabase } from '@/integrations/supabase/client';
import type { TrafficSignal, SignalState, SignalRuntime } from '@/types/signal';
import { SIGNAL_METADATA, DEFAULT_SETTINGS } from '@/types/signal';
import { totalCycleDuration, stateByElapsed } from '@/lib/signal-utils';

export function useSignals() {
  const [signals, setSignals] = useState<TrafficSignal[]>([]);
  const [loading, setLoading] = useState(true);
  const runtimesRef = useRef<Map<string, SignalRuntime>>(new Map());
  const initializedRef = useRef(false);

  const fetchSignals = useCallback(async () => {
    const { data, error } = await supabase
      .from('traffic_signals')
      .select('*');

    if (!error && data) {
      const enriched = (data as unknown as TrafficSignal[]).map(s => ({
        ...s,
        roadName: SIGNAL_METADATA[s.id]?.roadName || s.id,
        type: SIGNAL_METADATA[s.id]?.type || 'highway',
      }));
      setSignals(enriched);

      // Initialize runtimes on first fetch
      if (!initializedRef.current) {
        const baseOffset = Math.floor(Math.random() * totalCycleDuration(DEFAULT_SETTINGS.cycle));
        enriched.forEach(signal => {
          const meta = SIGNAL_METADATA[signal.id];
          let offset = baseOffset;
          if (meta?.type === 'side') {
            offset = (baseOffset + DEFAULT_SETTINGS.cycle.GREEN) % totalCycleDuration(DEFAULT_SETTINGS.cycle);
          }
          const cycle = { ...DEFAULT_SETTINGS.cycle };
          const initState = stateByElapsed(offset, cycle);
          runtimesRef.current.set(signal.id, {
            elapsed: offset,
            cycle,
            state: initState.state,
          });
        });
        initializedRef.current = true;
      }
    }
    setLoading(false);
  }, []);

  useEffect(() => {
    fetchSignals();
    const interval = setInterval(fetchSignals, 2000);
    return () => clearInterval(interval);
  }, [fetchSignals]);

  // Tick signal runtimes every second
  useEffect(() => {
    const interval = setInterval(() => {
      runtimesRef.current.forEach(runtime => {
        runtime.elapsed += 1;
        const info = stateByElapsed(runtime.elapsed, runtime.cycle);
        runtime.state = info.state;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, []);

  const updateSignal = useCallback(async (id: string, state: SignalState) => {
    await supabase.functions.invoke('update-signals', {
      body: { [id]: state },
    });
    setSignals(prev => prev.map(s => (s.id === id ? { ...s, state } : s)));
  }, []);

  const getRuntime = useCallback((id: string) => {
    return runtimesRef.current.get(id);
  }, []);

  return { signals, loading, updateSignal, getRuntime, runtimes: runtimesRef };
}
