export type SignalState = 'RED' | 'GREEN' | 'YELLOW';

export interface TrafficSignal {
  id: string;
  latitude: number;
  longitude: number;
  state: SignalState;
  updated_at: string;
  roadName?: string;
  type?: 'highway' | 'side';
}

export interface SignalRuntime {
  elapsed: number;
  cycle: CycleDurations;
  state: SignalState;
}

export interface CycleDurations {
  GREEN: number;
  YELLOW: number;
  RED: number;
}

export interface RouteSignalInfo {
  signal: TrafficSignal;
  distanceToRoute: number;
  distanceFromStart: number;
  state: SignalState;
  arrivalSec: number;
  waitSec: number;
  roadName: string;
}

export const SIGNAL_METADATA: Record<string, { roadName: string; type: 'highway' | 'side' }> = {
  'SIG-101': { roadName: 'Bajajnagar out', type: 'highway' },
  'SIG-102': { roadName: 'Pune - Sambhajinagar Highway', type: 'highway' },
  'SIG-103': { roadName: 'Bajaj Road', type: 'side' },
};

export const DEFAULT_SETTINGS = {
  averageSpeedKmh: 35,
  signalProximityMeters: 45,
  cycle: {
    GREEN: 35,
    YELLOW: 0,
    RED: 15,
  },
};
