import { useState, useCallback } from 'react';
import { useSignals } from '@/hooks/useSignals';
import TrafficMap from '@/components/TrafficMap';
import AdminPanel from '@/components/AdminPanel';
import RouteSignalPanel from '@/components/RouteSignalPanel';
import type { RouteSignalInfo } from '@/types/signal';

const Index = () => {
  const { signals, loading, updateSignal, getRuntime, runtimes } = useSignals();
  const [routeSignals, setRouteSignals] = useState<RouteSignalInfo[]>([]);
  const [routeDistance, setRouteDistance] = useState(0);
  const [speed, setSpeed] = useState(35);

  const handleRouteSignals = useCallback((info: RouteSignalInfo[]) => {
    setRouteSignals(info);
  }, []);

  const handleRouteDistance = useCallback((d: number) => {
    setRouteDistance(d);
  }, []);

  return (
    <div className="flex h-screen w-screen overflow-hidden">
      {/* Sidebar */}
      <div className="w-80 flex-shrink-0 bg-card border-r border-border flex flex-col overflow-hidden">
        <div className="p-4 border-b border-border">
          <h1 className="text-base font-mono font-bold text-primary tracking-tight">
            🚦 Traffic Signal Nav
          </h1>
          <p className="text-[10px] font-mono text-muted-foreground mt-1">
            Smart Signal Navigation System
          </p>
        </div>

        <div className="flex-1 overflow-y-auto p-3 space-y-3">
          {/* Status bar */}
          <div className="flex items-center gap-2 bg-secondary/50 rounded-md px-3 py-2">
            <div
              className={`w-2 h-2 rounded-full ${
                loading
                  ? 'bg-signal-yellow animate-pulse-signal'
                  : 'bg-signal-green'
              }`}
            />
            <span className="text-[10px] font-mono text-muted-foreground">
              {loading ? 'Connecting...' : `${signals.length} signals online`}
            </span>
          </div>

          <AdminPanel
            signals={signals}
            onUpdate={updateSignal}
            speed={speed}
            onSpeedChange={setSpeed}
            getRuntime={getRuntime}
          />

          <RouteSignalPanel
            routeSignals={routeSignals}
            routeDistance={routeDistance}
          />
        </div>

        <div className="p-3 border-t border-border">
          <p className="text-[9px] font-mono text-muted-foreground text-center">
            API: GET /signals • POST /signals/update
          </p>
        </div>
      </div>

      {/* Map */}
      <div className="flex-1 relative">
        <TrafficMap
          signals={signals}
          onRouteSignals={handleRouteSignals}
          onRouteDistance={handleRouteDistance}
          getRuntime={getRuntime}
          runtimes={runtimes}
          speed={speed}
        />
      </div>
    </div>
  );
};

export default Index;
